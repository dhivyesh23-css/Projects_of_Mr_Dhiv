#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <time.h>
#include <ctype.h>
#include <windows.h>

DWORD WINAPI threadfunc(void* data);

void game(char key, int m, int n);
void snaketail();
int board[17][19], m, n, trail[17][19], size=1, count=0, *ptr;
int Fx, Fy;

int main(){
    char key;
    srand(time(NULL));

    for(int i=0;i<17;i++){
        for(int j=0;j<19;j++){
            board[i][j]=1;
        }
    }

    for(int i=1;i<16;i++){
        for(int j=1;j<18;j++){
            board[i][j]=0;
        }
    }

    for(int i=0;i<17;i++){
        for(int j=0;j<19;j++){
            trail[i][j]=0;
        }
    }

    board[8][9]=2;

    printf("Enter E to start game");
    while(key != 'e'){
    key = getch();
    key = tolower(key);
    }

    Fx = (rand() % 15) + 1;
    Fy = (rand() % 17) + 1;
    
    system("cls");

    //game board shows here

    for(int i=0;i<17;i++){
        for(int j=0;j<19;j++){
            
            if(i==Fx && j==Fy){
                printf("@");
            }

            else if(board[i][j]==2){
                printf("O");
            }

            else if((j==0 || j==18)){
                printf("H");
            }
            else if((board[i][j+1]==1 && board[i][j-1]==1) && (j!=0 && j!=18)){
                printf("H");
            }
            
            else{printf(" ");}
        }
        printf("\n");
    }
    printf("\n");
    
    while(key != 'w' && key != 'a' && key != 's' && key != 'd'){
    key = getch();
    key = tolower(key);
    }
    game(key, m=8, n=9);

}

void game(char key, int m, int n){
    int highscore;

    HANDLE thread;
    FILE *fptr;
    fptr=fopen("snakegame_highscore.txt", "r");
    fscanf(fptr,"%d", &highscore);
    count++;
    
    if(m==Fx && n==Fy){
    while(board[Fx][Fy] != 0 || (trail[Fx][Fy]>count-size)){
    Fx = (rand() % 15) + 1;
    Fy = (rand() % 17) + 1;
    }
    size++;
    thread = CreateThread(NULL, 0, threadfunc, NULL, 0, NULL);
    }
    
    char tempkey;
    system("cls");
    
    if (_kbhit()) {
    tempkey = getch();
    tempkey = tolower(tempkey);
    if(key =='w' && (tempkey =='a' || tempkey =='w' || tempkey =='d')){
    key = tempkey;
    }
    else if(key =='a' && (tempkey =='w' || tempkey =='s' || tempkey =='a')){
    key = tempkey;
    }
    else if(key =='s' && (tempkey =='a' || tempkey =='s' || tempkey =='d')){
    key = tempkey;
    }
    else if(key =='d' && (tempkey =='d' || tempkey =='s' || tempkey =='w')){
    key = tempkey;
    }
    }
    
    if(tempkey=='x'){
        fclose(fptr);
        exit(0);
    }

    
    for(int i=0;i<17;i++){
        for(int j=0;j<19;j++){
            
            if(trail[i][j]>count-size){
                printf("O");
            }
            else if(board[i][j]==2){
                printf("O");
            }
            else if(key == 'w' && board[i+1][j]==2 && i-1>=0 && i-1<15 && j>0 && j<18){
                printf("O");
            }

            else if(key == 'a' && board[i][j+1]==2  && i-1>=0 && i-1<15 && j>0 && j<18){
                printf("O");
            }

            else if(key == 's' && board[i-1][j]==2 && i-1>=0 && i-1<15 && j>0 && j<18){
                printf("O");
            }

            else if(key == 'd' && board[i][j-1]==2 && i-1>=0 && i-1<15 && j>0 && j<18){
                printf("O");
            }

            else if(i==Fx && j==Fy){
                printf("@");
            }

            else if((j==0 || j==18)){
                printf("H");
            }
            else if((board[i][j+1]==1 && board[i][j-1]==1) && (j!=0 && j!=18)){
                printf("H");
            }
            
            else{printf(" ");}
        }
        printf("\n");
    }
    printf("\n");
    printf("key: %c", key);
    if(key == 'w'){
        printf(", Up");
    }
    else if(key == 'a'){
        printf(", Left");
    }
    else if(key == 's'){
        printf(", Down");
    }
    else if(key == 'd'){
        printf(", Right");
    }
    printf("\n\npress x to exit, size=%d", size);

        trail[m][n]=count;

        if(key =='w' && m-1>0 && m-1<16 && n>0 && n<18){
            board[m][n]=0;
            m=m-1;
            board[m][n]=2;
        }
        else if(key =='a' && m>0 && m<16 && n-1>0 && n-1<18){
            board[m][n]=0;
            n=n-1;
            board[m][n]=2;
        }
        else if(key =='s' && m+1>0 && m+1<16 && n>0 && n<18){
            board[m][n]=0;
            m=m+1;
            board[m][n]=2;
        }
        else if(key =='d' && m>0 && m<16 && n+1>0 && n+1<18){
            board[m][n]=0;
            n=n+1;
            board[m][n]=2;
        }

    //lose condition

    if(m<=0 || m>=16 || n<=0 || n>=18 || (trail[m][n]>count-size)){
        system("cls");

        if(size>highscore){
        highscore=size;
        fptr=fopen("snakegame_highscore.txt", "w");
        fprintf(fptr,"%d", highscore);
        }
        fclose(fptr);

        for(int i=0;i<17;i++){  
            if(i!=7){
            for(int j=0;j<19;j++){
            if((j==0 || j==18)){
                printf("H");
            }
            else if((board[i][j+1]==1 && board[i][j-1]==1) && (j!=0 && j!=18)){
                printf("H");
            }
            
            else{printf(" ");}
            }
            }
            else{
                if(highscore<10){
                printf("H   GAME OVER :(  H\nH                 H\nH   Highscore=%d   H", highscore);
                i+=2;
                }
                else if(highscore<100){
                printf("H   GAME OVER :(  H\nH                 H\nH   Highscore=%d  H", highscore);
                i+=2;
                }
                else if(highscore<1000){
                printf("H   GAME OVER :(  H\nH                 H\nH   Highscore=%d H", highscore);
                i+=2;
                }
                else{
                printf("H   GAME OVER :(  H\nH                 H\nH   Highscore=?   H", highscore);
                i+=2; 
                }
            }
        printf("\n");
    }
    printf("\n");
        
        exit(0);
    }
    
    if(key =='w' || key=='s'){
    Sleep(120);
    }
    else if(key =='a' || key=='d'){
    Sleep(120);
    }
    game(key, m, n);
}

DWORD WINAPI threadfunc(void* data) {
    Beep(500, 250);
    return(0);
}


