#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <ctype.h>

void game(int d);
int board[4][4],d,history[4][4],x,y;

int main(){
    int seed;

printf("Enter seed:");
scanf("%d", &seed);
srand(seed);
for(int i=0; i<4; i++){
    for(int j=0; j<4; j++){
    board[i][j]=0;
    }
}
for(int i=0; i<4; i++){
    for(int j=0; j<4; j++){
    history[i][j]=0;
    }
}

//starting position

board[rand()%4][rand()%4]=2;

do{
    x=rand()%4;
    y=rand()%4;
}while(board[x][y]==2);
board[x][y]=2;

system("cls");
printf("\n");

printf(" ___________________\n");
printf("|    |    |    |    |\n");
    for(int i=0; i<4; i++){
    printf("|");
    for(int j=0; j<4; j++){
    if(board[i][j]==0){
    printf("    |",board[i][j]);
    }
    else if(board[i][j]<=8){
    printf("  %d |",board[i][j]);
    }
    else if(board[i][j]<=64){
    printf(" %d |",board[i][j]);
    }
    else if(board[i][j]<=512){
    printf(" %d|",board[i][j]);
    }
    else if(board[i][j]<=2048){
    printf("%d|",board[i][j]);
    }
    }
    if(i!=3){
    printf("\n|----|----|----|----|\n");
    }
    else{
    printf("\n|____|____|____|____|\n");
    }
}
    printf("Press x to exit");
    
    d = getch();
    d = tolower(d);
while(d != 'w' && d != 'a' && d != 's' && d != 'd'){
    d = getch();
    d = tolower(d);
    }
game(d);
}

void game(int d){

if(d=='w'){

    for(int k=1; k<=3; k++){
    for(int j=0; j<4; j++){
    for(int i=1; i<4; i++){
        if(board[i][j]!=0 && board[i-1][j]==0){
            board[i-1][j]=board[i][j];
            board[i][j]=0;
        }
        else if(board[i][j]!=0 && board[i][j]==board[i-1][j] && history[i-1][j]==0 && history[i][j]==0){
            board[i-1][j]*=2;
            board[i][j]=0;
            history[i-1][j]=1;
            
        }
    }
    }
    }
}

else if(d=='s'){

    for(int k=1; k<=3; k++){
    for(int j=0; j<4; j++){
    for(int i=2; i>=0; i--){
        if(board[i][j]!=0 && board[i+1][j]==0){
            board[i+1][j]=board[i][j];
            board[i][j]=0;
        }
        else if(board[i][j]!=0 && board[i][j]==board[i+1][j] && history[i+1][j]==0 && history[i][j]==0){
            board[i+1][j]*=2;
            board[i][j]=0;
            history[i+1][j]=1;
        
        }
    }
    }
    }
}

else if(d=='a'){

    for(int k=1; k<=3; k++){
    for(int i=0; i<4; i++){
    for(int j=1; j<4; j++){
        if(board[i][j]!=0 && board[i][j-1]==0){
            board[i][j-1]=board[i][j];
            board[i][j]=0;
        }
        else if(board[i][j]!=0 && board[i][j]==board[i][j-1] && history[i][j-1]==0 && history[i][j]==0){
            board[i][j-1]*=2;
            board[i][j]=0;
            history[i][j-1]=1;
            
        }
    }
    }
    }
}

else if(d=='d'){

    for(int k=1; k<=3; k++){
    for(int i=0; i<4; i++){
    for(int j=2; j>=0; j--){
        if(board[i][j]!=0 && board[i][j+1]==0){
            board[i][j+1]=board[i][j];
            board[i][j]=0;
        }
        else if(board[i][j]!=0 && board[i][j]==board[i][j+1] && history[i][j+1]==0 && history[i][j]==0){
            board[i][j+1]*=2;
            board[i][j]=0;
            history[i][j+1]=1;
            
        }
    }
    }
    }
}

for(int i=0; i<4; i++){
    for(int j=0; j<4; j++){
    history[i][j]=0;
    }
}

do{
    x=rand()%4;
    y=rand()%4;
}while(board[x][y]!=0);
board[x][y]=2;

system("cls");
printf("\n");

printf(" ___________________\n");
printf("|    |    |    |    |\n");
for(int i=0; i<4; i++){
    printf("|");
    for(int j=0; j<4; j++){
    if(board[i][j]==0){
    printf("    |",board[i][j]);
    }
    else if(board[i][j]<=8){
    printf("  %d |",board[i][j]);
    }
    else if(board[i][j]<=64){
    printf(" %d |",board[i][j]);
    }
    else if(board[i][j]<=512){
    printf(" %d|",board[i][j]);
    }
    else if(board[i][j]<=2048){
    printf("%d|",board[i][j]);
    }
    }
    if(i!=3){
    printf("\n|----|----|----|----|\n");
    }
    else{
    printf("\n|____|____|____|____|\n");
    }
    }

    printf("Press x to exit");

    d = getch();
    d = tolower(d);
while(d != 'w' && d != 'a' && d != 's' && d != 'd' && d != 'x'){
    d = getch();
    d = tolower(d);
    }

if(d=='x'){
        exit(0);
    }
game(d);

}