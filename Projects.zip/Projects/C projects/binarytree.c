#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

struct binarytree
{
    int x;
    int f;
    int hf;
    struct binarytree *left;
    struct binarytree *right;
};
struct binarytree *head = NULL;

struct avltree
{
    int x;
    int f;
    int hf;
    int bf;
    struct avltree *left;
    struct avltree *right;
};
struct avltree *HEAD = NULL;

int n,count;
int *X;
int h,havl,z=0,H,HAVL,th=0;
int *arrptr,*arrptravl,valueflag=0,valueflagavl=0;
char d;

void input();
void randgen();
void checkrand(int i);
struct binarytree* insert(struct binarytree *p);
void add(struct binarytree *p,int x);
void createavlfrombst(struct avltree *p,int x);
struct binarytree* search(struct binarytree *p,int x);
void delete(struct binarytree*t);
int startheight(struct binarytree*p);
void height(struct binarytree*p);
void hfreset();
int startheightavl(struct avltree*p);
void heightavl(struct avltree*p);
void hfresetavl();
struct binarytree* looper(struct binarytree*t,int i);
struct avltree* looperavl(struct avltree*t,int i);
int twopower(int x);
int indsumofgp(int x);
int spacesumofgp(int x);
void spacefunc(int x);
void indfunc(int x);
void symbol();
void ssymbol();
void underscore();
void underspace();
int* scan();
void scanavl();
void print(int* x);

int main()
{
    srand(time(NULL));
    input();
}

void input()
{
    printf("\n\nMENU:-\n\n1.Enter number of random values to be inserted in the BST\n2.Add value to BST\n3.Delete value from BST\n4.Clear all values from BST\n5.Search value from BST\n6.Print The binary tree\n7.Print The balanced binary tree (AVL Tree)\n8.Exit\n");
    printf("\n");
    d = getch();
    while (d != '1' && d != '2' && d != '3' && d != '4' && d != '5' && d != '6' && d != '7' && d != '8')
    {
        d = getch();
    }

    if (d == '1')
    {
        printf("\nEnter here(max 99):");
        scanf("%d", &n);
        free(X);
        count=0;
        randgen();
        insert(head);
        count=0;
        startheight(head);
        printf("Height of tree:%d\n",h);
    }


    else if (d == '2')
    {
        printf("Enter value (shld be < 100) to be added:");
        int val;
        scanf("%d",&val);
        add(head,val);
        th=0;
        printf("Height of tree:%d\n",h);
    }

    else if (d == '3')
    {
        printf("Enter value to be deleted:");
        int val;
        scanf("%d",&val);
        delete(search(head,val));
        startheight(head);
    }

    else if (d == '4')
    {
        head=NULL;
    }

    else if (d == '5')
    {
        printf("Enter value to search:");
        int val;
        scanf("%d",&val);
        search(head,val);
    }

    else if (d == '6')
    {
    if(head==NULL){
        input();
    }
    z=1;
    startheight(head);
    scan();
    }

    else if (d == '7')
    {
    z=1;
    startheight(head);
    scan();
    if(head==NULL){
        input();
    }
    for(int i=0;i<twopower(h)-1;i++){
        if(arrptr[i] != 0){
        printf("%d ",*(arrptr+i));
        }
    }
    for(int i=0;i<twopower(h)-1;i++){
        int val=arrptr[i];
        if(arrptr[i] != 0){
        th=0;
        createavlfrombst(HEAD,val);
        }
    }
    havl=startheightavl(HEAD);
    printf("%d,%d",h,havl);
    z=1;
    scanavl();
    }

    else if (d == '8')
    {
        exit(0);
    }
    input();
}

void randgen()
{
    if (n == 0)
    {
        X = NULL;
    }
    else
    {   
        X = (int *)malloc((n) * sizeof(int));
        for (int i = 0; i < n; i++)
        {
            X[i] = (rand() % 99) + 1;
        }
    }

    // Checks if all random values are unique:-

    for (int i = 0; i < n; i++)
    {
        checkrand(i);
    }

    if (n > 0)
    {
        printf("Here are your value(s): [");
        for (int i = 0; i < n; i++)
        {
            if (i != n - 1)
            {
                printf("%d, ", *(X + i));
            }
            else
            {
                printf("%d", X[i]);
            }
        }
        printf("]\n");
    }
}

void checkrand(int i)
{
    for (int j = 0; j < n; j++)
    {
        if ((i != j && *(X + i) == *(X + j)))
        {
            *(X + i) = (rand() % 99) + 1;
            checkrand(i);
        }
    }
}

struct binarytree* insert(struct binarytree *p){

    if(count==n){
        return(0);
    }
    struct binarytree *temp = malloc(sizeof(struct binarytree));
    if(head == NULL){
        count=0;
        temp->x=X[0];
        temp->f=1;
        temp->hf=0;
        temp->left=NULL;
        temp->right=NULL;

        head=temp;
        count++;
        insert(head);
    }
    
    else{
    
        temp->x=X[count];
        temp->f=1;
        temp->hf=0;
        temp->left=NULL;
        temp->right=NULL;

        if(p->x > temp->x && p->left!=NULL){
            insert(p->left);
        }
        if(p->x < temp->x && p->right!=NULL){
            insert(p->right);
        }
        if(p->x > temp->x && p->left==NULL){
            p->left=temp;
            count++;
            insert(head);
        }
        if(p->x < temp->x && p->right==NULL){
            p->right=temp;
            count++;
            insert(head);
        }

        
    }
}

void add(struct binarytree *p,int v){

    struct binarytree *temp = malloc(sizeof(struct binarytree));
    if(head == NULL){
    
        temp->x=v;
        temp->f=1;
        temp->hf=0;
        temp->left=NULL;
        temp->right=NULL;
        th=1;
        h=1;
        head=temp;
    }
    
    else{
        th++;
        if(th>h){
            h=th;
        }
        temp->x=v;
        temp->f=1;
        temp->hf=0;
        temp->left=NULL;
        temp->right=NULL;

        if(p->x > temp->x && p->left!=NULL){
            add(p->left,v);
        }
        else if(p->x < temp->x && p->right!=NULL){
            add(p->right,v);
        }
        if(p->x > temp->x && p->left==NULL){
            p->left=temp;
            th++;
            if(th>h){
            h=th;
            }
        }
        else if(p->x < temp->x && p->right==NULL){
            p->right=temp;
            th++;
            if(th>h){
            h=th;
            }
        }

        
    }
}


void createavlfrombst(struct avltree *p,int v){

    struct avltree *temp = malloc(sizeof(struct avltree));
    if(HEAD == NULL){
    
        temp->x=v;
        temp->f=1;
        temp->hf=0;
        temp->bf=0;
        temp->left=NULL;
        temp->right=NULL;
        th=1;
        havl=1;
        HEAD=temp;
    }
    
    else{
        th++;
        if(th>havl){
            havl=th;
        }
        temp->x=v;
        temp->f=1;
        temp->hf=0;
        temp->bf=0;
        temp->left=NULL;
        temp->right=NULL;

        if(p->x > temp->x && p->left==NULL && p==HEAD){
            p->left=temp;
        }
        else if(p->x < temp->x && p->right==NULL && p==HEAD){
            p->right=temp;
        }
        else if(p->x > temp->x && p->left!=NULL){
            createavlfrombst(p->left,v);
        }
        else if(p->x < temp->x && p->right!=NULL){
            createavlfrombst(p->right,v);
        }
        if(HEAD->left!=NULL || HEAD->right!=NULL){
        if(startheightavl(HEAD->left) - startheightavl(HEAD->right) == 2){
            if(v < HEAD->left->x){
                struct avltree *A=HEAD;
                HEAD=HEAD->left;
                A->left=HEAD->right;
                HEAD->right=A;
            }
            else if(v > HEAD->left->x){
                struct avltree *A=HEAD;
                HEAD->left=HEAD->left->right->left;
                A->left=HEAD->left->right->right;
                HEAD->left->right->left=HEAD->left;
                HEAD->left->right->right=HEAD;
                HEAD=HEAD->left->right;
            }
        }
        else if(startheightavl(HEAD->left) - startheightavl(HEAD->right) == -2){
            if(v > HEAD->right->x){
                struct avltree *A=HEAD;
                HEAD=HEAD->right;
                A->right=HEAD->left;
                HEAD->left=A;
            }
            else if(v < HEAD->right->x){
                struct avltree *A=HEAD;
                HEAD->right=HEAD->right->left->right;
                A->right=HEAD->right->left->left;
                HEAD->right->left->right=HEAD->right;
                HEAD->right->left->left=HEAD;
                HEAD=HEAD->right->left;
            }
        }
    }
    }
}

int TH;
struct binarytree*hp;

int startheight(struct binarytree*p){
    hp=head;
    H=0;
    TH=0;
    height(head);
    hp=p;
    h=H;
    H=0;
    TH=0;
    hfreset();
    height(p);
    hfreset();
    return(H);
}

void hfreset(){
    int size=twopower(h)-1;
    head->hf=0;
    for(int i=1;i<size;i++){
        valueflag=0;
        struct binarytree* p=looper(head,i+1);
            if(valueflag==0){
            p->hf=0;
            }
    }
}

void height(struct binarytree*p){
    TH++;
    if(head->hf==1){
    return;
    }
    if(TH>H){
        H=TH;
    }
    if(p->left != NULL && p->left->hf != 1){
        height(p->left);
    }
    else if(p->right != NULL && p->right->hf != 1){
        height(p->right);
    }
    else if((p->left != NULL && p->left->hf == 1) || (p->right != NULL && p->right->hf == 1)){
        p->hf=1;
        TH=0;
        height(hp);
    }
    else if(p->left == NULL && p->right == NULL){
        p->hf=1;
        if(TH>H){
        H=TH;
        }
        TH=0;
        height(hp);
    }
}

int TH;
struct avltree*hpavl;

int startheightavl(struct avltree*p){
    hpavl=HEAD;
    HAVL=0;
    TH=0;
    heightavl(HEAD);
    hpavl=p;
    havl=HAVL;
    HAVL=0;
    TH=0;
    hfresetavl();
    if(p!=NULL){
    heightavl(p);
    hfresetavl();
    return(HAVL);
    }
    return(0);
}

void hfresetavl(){
    int size=twopower(havl)-1;
    HEAD->hf=0;
    for(int i=1;i<size;i++){
        valueflagavl=0;
        struct avltree* p=looperavl(HEAD,i+1);
            if(valueflagavl==0){
            p->hf=0;
            }
    }
}

void heightavl(struct avltree*p){
    TH++;
    if(HEAD->hf==1){
    return;
    }
    if(TH>HAVL){
        HAVL=TH;
    }
    if(p->left != NULL && p->left->hf != 1){
        heightavl(p->left);
    }
    else if(p->right != NULL && p->right->hf != 1){
        heightavl(p->right);
    }
    else if((p->left != NULL && p->left->hf == 1) || (p->right != NULL && p->right->hf == 1)){
        p->hf=1;
        TH=0;
        heightavl(hpavl);
    }
    else if(p->left == NULL && p->right == NULL){
        p->hf=1;
        if(TH>HAVL){
        HAVL=TH;
        }
        TH=0;
        heightavl(hpavl);
    }
}


struct binarytree* delpar;
int dir;
struct binarytree* search(struct binarytree *p,int v){

    if(head == NULL){
        printf("\nNothing to search lol\n");
    }
    
    else{
        if(p->x == v){
            printf("\nvalue found successfully!!");
            return(p);
        }
        else if(p->left != NULL && p->left->x==v){
            delpar=p;
            dir=0;
            printf("\nvalue found successfully!!");
            return(p->left);
        }
        else if(p->right != NULL && p->right->x==v){
            delpar=p;
            dir=1;
            printf("\nvalue found successfully!!");
            return(p->right);
        }
        else if(p->x > v && p->left!=NULL){
            search(p->left,v);
        }
        else if(p->x < v && p->right!=NULL){
            search(p->right,v);
        }
        else {
            printf("\nvalue not found");
        }
        
    }
}



void delete(struct binarytree*t){

    if(t->left == NULL && t->right == NULL){
        if(dir==0){
        delpar->left=NULL;
        }
        else if(dir==1){
        delpar->right=NULL;
        }
    }
    else if(t->left == NULL && t->right != NULL){
        if(dir==0){
        delpar->left=t->right;
        }
        else if(dir==1){
        delpar->right=t->right;
        }
    }
    else if(t->left != NULL && t->right == NULL){
        if(dir==0){
        delpar->left=t->left;
        }
        else if(dir==1){
        delpar->right=t->left;
        }
    }
    else{
        struct binarytree*p=t->right;
        delpar=t;
        dir=1;
        while(p->left!=NULL){
            delpar=p;
            dir=0;
            p=p->left;
        }
        t->x=p->x;
        delete(p);
    }
}


int space,ind;
int twopower(int x){
    int C=x,p=1;
    while(C!=0){
        p=p*2;
        C--;
    }
    return(p);
}

int indsumofgp(int x){
    int sum=0;
    for(int i=0;i<x;i++){
        sum+=twopower(i+1);
    }
    return(sum);
}

int spacesumofgp(int x){
    int sum=2;
    for(int i=1;i<x;i++){
        sum+=twopower(i+1);
    }
    return(sum);
}

void indfunc(int x){
    if(x>=1 && x<=(h-1)){
    for(int i=0;i<indsumofgp(h-x);i++){
        printf(" ");
    }
    }
}

void spacefunc(int x){
    if(x>=2 && x<=h){
    for(int i=0;i<spacesumofgp(h-(x-1));i++){
        printf(" ");
    }
    }
}


int* scan(){
    valueflag=0;
    int size=twopower(h)-1;
    int arr[size];
    arr[0]= head->x;
    for(int i=1;i<size;i++){
        struct binarytree* p=looper(head,i+1);
        if(valueflag==0){
            arr[i] = (p->x);
        }
        else{ 
            arr[i]=0;
        }
        valueflag=0;
    }
    arrptr=arr;
    if(d=='6'){
    print(arrptr);
    }
}


void scanavl(){
    valueflagavl=0;
    int size=twopower(havl)-1;
    int arr[size];
    arr[0]= HEAD->x;
    for(int i=1;i<size;i++){
        struct avltree* p=looperavl(HEAD,i+1);
        if(valueflagavl==0){
            arr[i] = (p->x);
        }
        else{
            arr[i]=0;
        }
        valueflagavl=0;
    }
    arrptravl=arr;
    h=havl;
    print(arrptravl);
}

void print(int* x){
    int size=twopower(h)-1;
    for(int i=0;i<size;i++){
        for(int j=0;j<h;j++){
            if(i+1 == twopower(j)){
                z++;
                indfunc(z-1);
            }
        }

    if(x[i]==0){
        printf("  ");
    }
    else if(x[i]<10){
    printf("0%d",x[i]);
    }
    else{
    printf("%d",x[i]);
    }
    spacefunc(z-1);
    if(i+1 == twopower(h-1)-1){
        ssymbol();
    }
    else{
    for(int j=0;j<h-1;j++){
            if(i+1 == twopower(j+1)-1){
                symbol();
            }
        }
    }
    }
}

void symbol(){
    printf("\n");
    printf("   ");
    indfunc(z);
    for(int i=twopower(z-1);i<=twopower(z)-1;i++){
        if(arrptr[i-1]>0 && i%2==0){
        underscore();
        printf("/");
        }
        else if(arrptr[i-1]>0 && i%2==1){
        printf("\\");
        underscore();
        }
        else{
            underspace();
            printf(" ");
        }
        if(i%2==0){
        printf("  ");
        }
        if(i%2==1){
        printf("      ");
        spacefunc(z);
        }
    }

    printf("\n  ");
    indfunc(z);
    for(int i=twopower(z-1);i<=twopower(z)-1;i++){
        if(arrptr[i-1]>0 && i%2==0){
        printf("/");
        }
        else if(arrptr[i-1]>0 && i%2==1){
        printf("\\");
        }
        else{
            printf(" ");
        }
        spacefunc(z);
        if(i%2==0){
        printf("\b\b");
        }
        if(i%2==1){
        printf("    ");
        }
    }
    printf("\n");
}


void ssymbol(){
    printf("\n");
    printf(" ");
    for(int i=twopower(h-1);i<=twopower(h)-1;i++){
        if(arrptr[i-1]>0 && i%2==0){
            printf("/");
        }

        else if(arrptr[i-1]>0 && i%2==1){
            printf("\\");
        }
        else{
            printf(" ");
        }
        if(i%2==0){
            printf("  ");
        }
        else if(i%2==1){
            printf("    ");
        }
    }
    printf("\n");
}

void underscore(){
    for(int i=0;i<=(spacesumofgp(h-(z))-6/2);i++){
        printf("_");
    }
}
void underspace(){
    for(int i=0;i<=(spacesumofgp(h-(z))-6/2);i++){
        printf(" ");
    }
}

struct binarytree* looper(struct binarytree*temp,int i){
    int mod=i,modcount=1;
    while(mod != 0 && mod !=1){
        mod=mod/2;
        modcount++;
    }
    mod=i;
    int ins[modcount-1];
    int j=modcount-1;
    while(mod != 0 && mod !=1){
        ins[j-1]=mod%2;
        j--;
        mod=mod/2;
    }
    for(int k=0; k<modcount-1;k++){
        if(ins[k]==1){
            if(temp->right==NULL){
                valueflag=1;
                break;
            }
            temp=temp->right;
        }
        else if(ins[k]==0){
            if(temp->left==NULL){
                valueflag=1;
                break;
            }
            temp=temp->left;
        }
    }
    return(temp);
}

struct avltree* looperavl(struct avltree*temp,int i){
    int mod=i,modcount=1;
    while(mod != 0 && mod !=1){
        mod=mod/2;
        modcount++;
    }
    mod=i;
    int ins[modcount-1];
    int j=modcount-1;
    while(mod != 0 && mod !=1){
        ins[j-1]=mod%2;
        j--;
        mod=mod/2;
    }
    for(int k=0; k<modcount-1;k++){
        if(ins[k]==1){
            if(temp->right==NULL){
                valueflagavl=1;
                break;
            }
            temp=temp->right;
        }
        else if(ins[k]==0){
            if(temp->left==NULL){
                valueflagavl=1;
                break;
            }
            temp=temp->left;
        }
    }
    return(temp);
}