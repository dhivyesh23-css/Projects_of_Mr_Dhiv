#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>

int survey(int m, int n);

int frame[41][41], rowmask[41][121], columnmask[41][121];


int main(){
int I=9,J=9,seed;

//Maze generator

printf("\nenter maze seed: ");
scanf("%d", &seed);
srand(seed);

for(int i=0; i<41; i++){
        for(int j=0; j<41; j++){
            frame[i][j]=1;
        }
    }

for(int i=0; i<41; i++){
        for(int j=0; j<121; j++){
            rowmask[i][j]=0;
        }
    }

for(int i=0; i<41; i++){
        for(int j=0; j<121; j++){
            columnmask[i][j]=0;
        }
    }



frame[0][19]=0;
frame[40][21]=0;

survey(I,J);

printf("\n\n\n");

for(int i=0; i<=40; i++){
    for(int j=0; j<40; j++){
        if(frame[i][j]==1 && (frame[i][j+1]==1 || frame[i][j-1]==1) && frame[i][j-1]==0 && frame[i-1][j]==0){
        rowmask[i][3*j]=2;
        rowmask[i][3*j+1]=1;
        rowmask[i][3*j+2]=1;
        }
        else if(frame[i][j]==1 && frame[i][j+1]==1){
        rowmask[i][3*j]=1;
        rowmask[i][3*j+1]=1;
        rowmask[i][3*j+2]=1;
        }
    }
}


for(int i=0; i<=40; i++){
    for(int j=0; j<=40; j++){
        if(frame[i][j]==1 && frame[i-1][j]==1 && rowmask[i][3*j]==2){
        columnmask[i][3*j]=0;
        }
        else if(frame[i][j]==1 && frame[i-1][j]==1 && rowmask[i][3*j]!=2){
        columnmask[i][3*j]=1;
        }
    }
}

for(int i=0; i<41; i++){
        for(int j=0; j<121; j++){
            if(columnmask[i][j]==1 && rowmask[i][j]!=2){
            printf("|");
            }
            else if(rowmask[i][j]==1){
            printf("_");
            }
            else {
            printf(" ");
            }
        }
        printf("\n");
    }

}

int survey(int m, int n){
    int count=0, way;
    way = rand() % 4;
    frame[m][n]=0;

    for(int i=1; i<40; i+=2){
        for(int j=1; j<40; j+=2){
            count += frame[i][j];
        }
    }

    if(count==0){
        return(0);
    }
    
    if(way == 0 && m-2 > 0){
        if(frame[m-2][n]==1){
        frame[m-1][n]=0;
        }
        survey(m-2, n);
    }

    if(way == 1 && n+2 < 40){
        if(frame[m][n+2]==1){
        frame[m][n+1]=0;
        }
        survey(m, n+2);
    }

    if(way == 2 && m+2 < 40){
        if(frame[m+2][n]==1){
        frame[m+1][n]=0;
        }
        survey(m+2, n);
    }

    if(way == 3 && n-2 > 0){
        if(frame[m][n-2]==1){
        frame[m][n-1]=0;
        }
        survey(m, n-2);
    }

    if(count != 0){
        survey(m,n);
    }
}


