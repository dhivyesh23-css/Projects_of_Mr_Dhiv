#include<stdio.h>
#include<stdlib.h>

/*Instructions:-
1) First enter row value, press enter and enter column value
2) This will start your game at that cell
3) After this start playing minesweeper!!!
4) After initiating the first cell, the game will ask for an addition input after entering row and column.
5) This input decides your click, 0 for left click, 1 for right click
6) left click is used to dig, right click is used to flag
7) If you want to unflag a flagged cell, flag it again*/

int survey(int m, int n);
int test();


int board[8][8];
int display[8][8];
int mask[8][8];
int flagmark[8][8];
int win=0;
int main(){
    int seed, I, J, click=0;
    printf("Enter seed: ");
    scanf("%d", &seed);

    //game ui
    
    printf("        1    2    3    4    5    6    7    8\n\n");
    printf("      ________________________________________\n");
    
    for(int i=0; i<8; i++){
        printf("     |                                        |\n");
        printf("%d    |", i+1);
        for(int j=0; j<8; j++){
            printf("  *  ");
        }
        printf("|\n");
        
    }
    printf("     |________________________________________|\n\n");

    printf("Enter cell row: ");
    scanf("%d", &I);
    I=I-1;
    printf("Enter cell column: ");
    scanf("%d", &J);
    J=J-1;
    
    srand(seed);
    printf("\n\n");
    //placing mines randomly, 1s are mines, 0s are safe
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            board[i][j]=rand() % 6;
            if(board[i][j]>0){
                board[i][j]=0;
            }
            else board[i][j]=1;
        }
    }
    
    //removing all mines near spawn (if any)
    for(int k=-1; k<=1; k++){
        for(int l=-1; l<=1; l++){
            board[I+k][J+l]=0;
        }
    }
    

    //display numbers of the tiles
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            display[i][j]=0;
            if(board[i][j]==1){
            display[i][j]=9;
            }
            for(int k=-1; k<=1; k++){
                for(int l=-1; l<=1; l++){
                    if(board[i][j]!=1 && board[i+k][j+l]==1 && i+k >=0 && i+k <=7 && j+l >=0 && j+l <=7){
                    display[i][j]+=1;
                    }
                }
            }
        }
    }

    //screen masking
    
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            mask[i][j]=0;
        }
    }

    //Flag marking
    
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            flagmark[i][j]=0;
        }
    }


    //path finding
    
    if (board[I][J]==0){
    mask[I][J]=1;
    survey(I,J);
    }

    while(win!=64){
    
    printf("        1    2    3    4    5    6    7    8\n\n");
    printf("      ________________________________________\n");
    
    for(int i=0; i<8; i++){
        printf("     |                                        |\n");
        printf("%d    |", i+1);
        for(int j=0; j<8; j++){
            if (flagmark[i][j]==1){
            printf("  @  ");
            }
            else if(flagmark[i][j]==0 && mask[i][j]==0){
            printf("  *  ");
            }
            else if(mask[i][j]==0){
            printf("  *  ");
            }
            else if(mask[i][j]==1){
            if (display[i][j] != 0){
            printf("  %d  ", display[i][j]);
            }
            else if(display[i][j] == 0){
            printf("     ");
            }
            }
        }
        printf("|\n");
        
    }
    printf("     |________________________________________|\n");

    printf("\n\n");


    printf("Enter cell row: ");
    scanf("%d", &I);
    I=I-1;
    printf("Enter cell column: ");
    scanf("%d", &J);
    scanf("%d", &click);
    J=J-1;
    if(click==1 && flagmark[I][J]==0 && mask[I][J]==0){
        flagmark[I][J]++;
    }

    else if(click==1 && flagmark[I][J]==1 && mask[I][J]==0){
        flagmark[I][J]--;
    }

    //lose condition
    if(board[I][J] == 1 && click==0){
    printf("        1    2    3    4    5    6    7    8\n\n");
    printf("      ________________________________________\n");
    
    for(int i=0; i<8; i++){
        printf("     |                                        |\n");
        printf("%d    |", i+1);
        for(int j=0; j<8; j++){
            if (board[i][j]==1){
            printf("  X  ");
            }
            else if(mask[i][j]==0){
            printf("  *  ");
            }
            else if(mask[i][j]==1){
            if (display[i][j] != 0){
            printf("  %d  ", display[i][j]);
            }
            else if(display[i][j] == 0){
            printf("     ");
            }
            }
        }
        printf("|\n");
        
    }
    printf("     |________________________________________|\n");

    printf("\n\n");
    printf("------------------------game over :(------------------------\n\n");
    exit(0);
    }
    if(click==0){
    mask[I][J]=1;
    }
    if (display[I][J]==0){
    survey(I,J);
    }
    test();
    }
    printf("\n\n\n\n\n\n\n");
    printf("\n_         _                                        __                __           _      _     _____");
    printf("\n\\\\       //    ________     __         __          ||                ||    __    | \\    | |   |     |");
    printf("\n \\\\     //    /        \\    ||         ||          ||                ||    ||    | \\\\   | |   |     |");
    printf("\n  \\\\   //    ||        ||   ||         ||          ||                ||    ||    | |\\\\  | |   |     |");
    printf("\n   \\\\ //     ||        ||   ||         ||          \\\\       __       //    ||    | | \\\\ | |   |     |");
    printf("\n    | |      ||        ||   ||         ||           \\\\     //\\\\     //     ||    | |  \\\\| |    \\___/");
    printf("\n    | |      ||        ||    \\\\       //             \\\\___//  \\\\___//      ||    | |   \\\\ |     ___");
    printf("\n    |_|       \\________/      \\\\_____//               \\___/    \\___/       ||    |_|    \\_|    |___|\n\n\n");
}
    
    int survey(int m, int n){
        for(int k=-1; k<=1; k++){
            for(int l=-1; l<=1; l++){
                if(m+k >=0 && m+k <=7 && n+l >=0 && n+l <=7){
                    mask[m][n]=1;
                    if(k == 0 && l == 0){
                        continue;
                    }
                    if (display[m+k][n+l]==0 && mask[m+k][n+l]==0){
                    survey(m+k, n+l);
                    }
                    mask[m+k][n+l]=1;
                }
            }
        }
    }

    int test(){
        win=0;
        for(int i=0; i<8; i++){
            for(int j=0; j<8; j++){
                if(board[i][j] == flagmark[i][j]){
                win++;
                }
            }
        }
    return(win);
    }