import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:hype/pages/homepages/club_page/clubdetailsscreen.dart';




class ClubPage extends StatefulWidget {
  const ClubPage({super.key});

  @override
  State<ClubPage> createState() => _ClubPageState();
}

class _ClubPageState extends State<ClubPage> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> clubs = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchClubs();
  }

  Future<void> fetchClubs() async {
  try {
    final response = await supabase.from('clubs').select('*');
    final newClubs = List<Map<String, dynamic>>.from(response)??[]; 

    if (mounted) {
      setState(() {
        clubs = newClubs; 
        isLoading = false;
      });
    }
  } catch (e) {
    print("Error fetching clubs: $e");
    if (mounted) {
      setState(() {
        isLoading = false;
      });
    }
  }
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(title: Text("Clubs")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.2,
                children: [
                  _buildClubCard(
                    context,
                    "Add New Clubs",
                    Icon(Icons.add, size: 30, color:Theme.of(context).colorScheme.primary), // Pass a Widget
                    isNewBoard: true,
                  ),
                  ...clubs.map((club) => _buildClubCard(
                        context,
                        club['name'] ?? 'Unnamed Club',
                        club['icon'] != null
                            ? CircleAvatar(
                                backgroundImage: NetworkImage(club['icon']),
                                radius: 35, 
                              )
                            : Icon(Icons.image, size: 24),
                        club: club, // Pass club data
                      )),
                ],
              ),
      ),
    );
  }

   Widget _buildClubCard(
    BuildContext context,
    String title,
    Widget iconWidget, { 
    bool isNewBoard = false,
    Map<String, dynamic>? club,
  }) {
    return GestureDetector(
      onTap: () async {
      if (isNewBoard) {
        final result = await Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ClubNewScreen()),
        );

        if (result == true) { // If a new club was created
          fetchClubs(); // Refresh the club list
        }
      } else if (club != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ClubDetailsScreen(club: club),
          ),
        );
      }
    },

      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(20),
        ),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            iconWidget, // Use the Widget dynamically
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 16, color: Theme.of(context).colorScheme.primary,fontWeight: FontWeight.w500),
                ),
                if (club?['is_verified'] == true) // Show icon only if verified
                  Padding(
                    padding: const EdgeInsets.only(left: 5),
                    child: Icon(Icons.verified, size: 18, color: Theme.of(context).colorScheme.primary),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


class ClubNewScreen extends StatefulWidget {
  const ClubNewScreen({super.key});

  @override
  State<ClubNewScreen> createState() => _ClubNewScreenState();
}

class _ClubNewScreenState extends State<ClubNewScreen> {
  // Move controllers inside the state class
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descController = TextEditingController();
  final TextEditingController clubtypeController = TextEditingController();
  final TextEditingController clubiconController = TextEditingController();
  final TextEditingController clubposterController = TextEditingController();

  final supabase = Supabase.instance.client;

  @override
  void dispose() {
    // Dispose controllers to prevent memory leaks
    nameController.dispose();
    descController.dispose();
    clubtypeController.dispose();
    clubiconController.dispose();
    clubposterController.dispose();
    super.dispose();
  }

  Future<void> createClub() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("User not logged in")),
      );
      return;
    }

    try {
      final String name = nameController.text.trim();
      final String description = descController.text.trim();
      final String clubType = clubtypeController.text.trim();
      final String clubIcon = clubiconController.text.trim();
      final String clubPoster = clubposterController.text.trim();

      if (name.isEmpty || description.isEmpty || clubType.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please fill all required fields")),
        );
        return;
      }

      // Insert club into Supabase
      await supabase.from('clubs').insert({
        'name': name,
        'description': description,
        'club_type': clubType,
        'owner': user.id,
        'is_verified': user.email?.endsWith("admin@gmail.com") ?? false,
        'icon': clubIcon,
        'poster': clubPoster,
      });
      // Show success message & navigate back
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Club created successfully!")),
      );
      Navigator.pop(context, true);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error creating club: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Club")),
      body: SingleChildScrollView(
        child: Center(
          child: SizedBox(
            width: 350,
            child: Column(
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: "Name",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: clubtypeController,
                  decoration: const InputDecoration(
                    labelText: "Club Type",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: descController,
                  decoration: const InputDecoration(
                    labelText: "Club Description",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: clubiconController,
                  decoration: const InputDecoration(
                    labelText: "Enter club icon URL",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: clubposterController,
                  decoration: const InputDecoration(
                    labelText: "Enter club poster URL",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: createClub,
                      child: const Text("Save"),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text("Cancel"),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}