import 'package:flutter/material.dart';
import 'package:hype/auth/auth_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final authService = AuthService();
  final _supabase = Supabase.instance.client;

  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  bool isEditing = false;
  String name = "";
  String description = "";

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  Future<void> fetchUserData() async {
  final user = _supabase.auth.currentUser;
  if (user != null) {
    final userId = user.id;
    final response = await _supabase
        .from('user_profile')
        .select('name, description')
        .eq('id', userId)
        .maybeSingle();
    
    if (response != null && mounted) { 
      setState(() {
        name = response['name'] ?? "";
        description = response['description'] ?? "";
        nameController.text = name;
        descriptionController.text = description;
      });
    }
  }
}


  Future<void> updateUserDataToSupabase() async {
    final user = _supabase.auth.currentUser;
    if (user != null) {
      final userId = user.id;
      await _supabase.from('user_profile').update({
        'name': nameController.text,
        'description': descriptionController.text,
      }).eq('id', userId);
    }
  }

  void toggleEditMode() {
    if (mounted) {
      setState(() {
        isEditing = !isEditing;
      });
    }
  }

  void saveChanges() async {
    await updateUserDataToSupabase();
    await fetchUserData();
    if (mounted) {
      setState(() {
        isEditing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text("Profile"),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: toggleEditMode,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage('https://lh3.googleusercontent.com/a/ACg8ocL_GN_7ZftYkX3BoGRijQ9l930Vc86pcZEgBo9ZIu1pE943UNjx=s360-c-no'),
            ),
            const SizedBox(height: 16),
            Text(authService.getCurrentUserEmail() ?? "No email found"),
            const SizedBox(height: 16),
            TextField(
              controller: nameController,
              enabled: isEditing,
              decoration: InputDecoration(
                labelText: "Name",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              enabled: isEditing,
              decoration: InputDecoration(
                labelText: "Description",
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16),
            if (isEditing)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: saveChanges,
                    child: const Text("Save"),
                  ),
                  ElevatedButton(
                    onPressed: toggleEditMode,
                    child: const Text("Cancel"),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
