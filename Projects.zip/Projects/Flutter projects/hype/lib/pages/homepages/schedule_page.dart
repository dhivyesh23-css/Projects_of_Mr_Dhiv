import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});

  @override
  _SchedulePageState createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  Map<DateTime, bool> _markedDates = {};

  @override
  void initState() {
    super.initState();
    _loadMarkedDates();
  }

  // Load marked dates from local storage
  Future<void> _loadMarkedDates() async {
    final prefs = await SharedPreferences.getInstance();
    final String? storedData = prefs.getString('marked_dates');

    if (storedData != null) {
      final decoded = jsonDecode(storedData) as Map<String, dynamic>;
      setState(() {
        _markedDates = decoded.map((key, value) =>
            MapEntry(DateTime.parse(key), value as bool));
      });
    }
  }

  // Toggle marking/unmarking a date
  Future<void> _toggleMarkDate(DateTime day) async {
    setState(() {
      _markedDates[day] = !(_markedDates[day] ?? false);
    });

    final prefs = await SharedPreferences.getInstance();
    final encodedData = jsonEncode(_markedDates.map((key, value) =>
        MapEntry(key.toIso8601String(), value)));

    await prefs.setString('marked_dates', encodedData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 40),
            const Text("Schedule", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TableCalendar(
              firstDay: DateTime.utc(2020, 1, 1),
              lastDay: DateTime.utc(2030, 12, 31),
              focusedDay: _focusedDay,
              selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
                _toggleMarkDate(selectedDay);
              },
              headerStyle: const HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,
              ),
              calendarBuilders: CalendarBuilders(
                markerBuilder: (context, date, events) {
                  if (_markedDates[date] == true) {
                    return Container(
                      margin: const EdgeInsets.all(4.0),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 0, 0, 0),
                        shape: BoxShape.circle,
                      ),
                      width: 10.0,
                      height: 10.0,
                    );
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(height: 20),
            const Text("Marked Dates:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView(
                children: _markedDates.entries
                    .where((entry) => entry.value)
                    .map((entry) => ListTile(
                          title: Text(
                              "${entry.key.toLocal()}".split(' ')[0]),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Color.fromARGB(255, 0, 0, 0)),
                            onPressed: () => _toggleMarkDate(entry.key),
                          ),
                        ))
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
