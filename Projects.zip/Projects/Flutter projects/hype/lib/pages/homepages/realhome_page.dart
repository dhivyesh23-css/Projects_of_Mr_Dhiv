import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:hype/auth/auth_service.dart';


class RealhomePage extends StatefulWidget {
  const RealhomePage({super.key});

  @override
  _RealhomePageState createState() => _RealhomePageState();
}

class _RealhomePageState extends State<RealhomePage> {
  final ScrollController _mainScrollController = ScrollController();
  final SupabaseClient supabase = Supabase.instance.client;
  final authService = AuthService();

  int _currentAdIndex = 0;

  // Advertisement Images
  final List<String> adImages = [
    'https://i.imgur.com/tZqZa3O.jpeg',
    'https://i.imgur.com/FG9mAMa.jpeg',
    'https://i.imgur.com/khZhquu.jpeg',
  ];
  

  // Event lists from Supabase
  List<Map<String, dynamic>> recommendedEvents = [];
  List<Map<String, dynamic>> eventsThisWeek = [];
  List<Map<String, dynamic>> browseByCategory = [];
  List<Map<String, dynamic>> ongoingEvents = [];

  // Key for the events section (to scroll down to)
  final GlobalKey _eventsKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    fetchEvents();
  }

  Future<void> fetchEvents() async {
    final response = await supabase.from('events').select('poster, hype');

    if (response.isNotEmpty) {
      setState(() {
        recommendedEvents = response.take(4).toList();
        eventsThisWeek = response.skip(4).take(4).toList();
        browseByCategory = response.skip(8).take(4).toList();
        ongoingEvents = response.skip(12).take(4).toList();
      });
    }
  }

  void _scrollToEvents() {
    final RenderBox? box = _eventsKey.currentContext?.findRenderObject() as RenderBox?;
    if (box != null) {
      final position = box.localToGlobal(Offset.zero).dy + _mainScrollController.offset;
      _mainScrollController.animateTo(
        position,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  void logout() async {
    await authService.signOut();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 255, 177, 22),
        title: const Text("Home"),
        actions: [
          IconButton(icon: const Icon(Icons.chat), onPressed: () {}),
          IconButton(icon: const Icon(Icons.search), onPressed: () {}),
          IconButton(icon: const Icon(Icons.notifications), onPressed: () {}),
          IconButton(icon: const Icon(Icons.logout), onPressed: logout),
        ],
      ),
      body: SingleChildScrollView(
        controller: _mainScrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Advertisements Section
            Container(
              height: 150,
              margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.amber),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  PageView.builder(
                    itemCount: adImages.length,
                    onPageChanged: (index) {
                      setState(() {
                        _currentAdIndex = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      return Image.network(adImages[index], fit: BoxFit.cover);
                    },
                  ),
                  // Page Indicator Dots
                  Positioned(
                    bottom: 8,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(adImages.length, (index) {
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: _currentAdIndex == index ? 10 : 8,
                          height: _currentAdIndex == index ? 10 : 8,
                          decoration: BoxDecoration(
                            color: _currentAdIndex == index ? Colors.amber : Colors.grey,
                            shape: BoxShape.circle,
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),

            // Scroll Down Button to jump to events sections
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.amber),
                onPressed: _scrollToEvents,
                child: const Text("Scroll Down to Events"),
              ),
            ),

            // Events Sections
            Container(
              key: _eventsKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  sectionTitle("Recommended Events"),
                  horizontalScroll(recommendedEvents, isLarge: true),
                  sectionTitle("Events This Week"),
                  horizontalScroll(eventsThisWeek),
                  sectionTitle("Browse by Category"),
                  horizontalScroll(browseByCategory),
                  sectionTitle("Ongoing Events"),
                  horizontalScroll(ongoingEvents),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Section Title Widget
  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    );
  }

  // Horizontal Scrollable List for Event Cards
  Widget horizontalScroll(List<Map<String, dynamic>> events, {bool isLarge = false}) {
    final double cardWidth = isLarge ? 200 : 150;
    final double cardHeight = isLarge ? 250 : 180;

    return SizedBox(
      height: cardHeight + 40,
      child: Row(
        children: [
          scrollButton(Icons.arrow_back_ios),
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: events.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: eventCard(
                    events[index]['poster'],
                    cardWidth,
                    cardHeight,
                    isLarge,
                    events[index]['hype'],
                  ),
                );
              },
            ),
          ),
          scrollButton(Icons.arrow_forward_ios),
        ],
      ),
    );
  }

  // Scroll Button (placeholder for additional scroll logic if needed)
  Widget scrollButton(IconData icon) {
    return IconButton(
      icon: Icon(icon, size: 24),
      onPressed: () {},
    );
  }

  // Event Card Widget – Displays Hype Value
  Widget eventCard(String imageUrl, double width, double height, bool isLarge, int hype) {
    return Stack(
      children: [
        Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            image: DecorationImage(
              image: NetworkImage(imageUrl),
              fit: BoxFit.cover,
            ),
          ),
        ),
        if (isLarge) fireRating(hype),
      ],
    );
  }


  Widget fireRating(int hype) {
    return Positioned(
      top: 10,
      left: 10,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.6),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          "🔥 $hype",
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
