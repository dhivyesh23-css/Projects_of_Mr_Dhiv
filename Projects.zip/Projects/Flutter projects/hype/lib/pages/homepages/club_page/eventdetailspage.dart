import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Eventdetailspage extends StatefulWidget {
  final Map<String, dynamic> event;

  const Eventdetailspage({super.key, required this.event});

  @override
  State<Eventdetailspage> createState() => _EventdetailspageState();
  
}

class _EventdetailspageState extends State<Eventdetailspage> {
  bool isRegistered = false;
  int hypeCount = 0;
  final supabase = Supabase.instance.client;
  bool isLoading = true; // Add loading state

  @override
  void initState() {
    super.initState();
    _loadEventDetails();
  }

Future<void> _loadEventDetails() async {
    try {
      final eventDetails = await supabase
          .from('events')
          .select('hype') // Select only the hype column for efficiency
          .eq('id', widget.event['id'])
          .single();

      if (eventDetails != null && eventDetails is Map<String, dynamic>) {
        setState(() {
          hypeCount = eventDetails['hype'] ?? 0;
          isLoading = false;
        });
      } else {
        setState(() {
          hypeCount = 0;
          isLoading = false;
        });
      }

      // Check registration after loading event details
      await _checkRegistration();
    } catch (e) {
      print("Error loading event details: $e");
      setState(() {
        isLoading = false;
      });
    }
  }


  Future<void> _checkRegistration() async {
    try {
      final user = supabase.auth.currentUser;
      if (user != null) {
        final registration = await supabase
            .from('event_members')
            .select('*')
            .eq('event_id', widget.event['id'])
            .eq('user_id', user.id)
            .single();

        setState(() {
          isRegistered = registration != null;
        });
      }
    } catch (e) {
      print("Error checking registration: $e");
    }
  }

  Future<void> _toggleRegistration() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("You must be logged in to register.")),
      );
      return;
    }

    setState(() {
      isLoading = true; // Set loading to true while operation is in progress
    });

    try {
      if (isRegistered) {
        await supabase
            .from('event_members') // Use event_members table
            .delete()
            .eq('event_id', widget.event['id'])
            .eq('user_id', user.id);

        await _updateHype(-1);
      } else {
        await supabase.from('event_members').insert({
          'event_id': widget.event['id'],
          'user_id': user.id,
        });

        await _updateHype(1);
      }

      setState(() {
        isRegistered = !isRegistered;
      });
    } catch (e) {
      print("Error toggling registration: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("An error occurred: $e")),
      );
    } finally {
      setState(() {
        isLoading = false; // Set loading to false after operation completes
      });
    }
  }

  Future<void> _updateHype(int change) async {
    try {
      final updatedEvent = await supabase
          .from('events')
          .update({'hype': hypeCount + change})
          .eq('id', widget.event['id'])
          .select('hype') // Select hype after update
          .single();

      if (updatedEvent != null && updatedEvent is Map<String, dynamic>) {
        setState(() {
          hypeCount = updatedEvent['hype'] ?? 0;
        });
      }
    } catch (e) {
      print("Error updating hype: $e");
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(" EVENTS", style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.amber[700],
      ),
        body: isLoading // Show loading indicator while data is being fetched
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 📌 Event Poster
            Container(
            height: 180,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: NetworkImage(widget.event['poster']), // Ensure this key exists in your event data
                fit: BoxFit.cover, // Adjusts the image to fill the container
              ),
            ),
          ),
          SizedBox(height: 16),

            // 📌 Event Name & Subtitle
            Text(
              '${widget.event['name']} Event', // Proper string interpolation
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),

            // 📌 Register Button
            Center(
  child: Center(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.yellow,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 50, vertical: 12),
                      ),
                      onPressed: _toggleRegistration,
                      child: Text(isRegistered ? "UNREGISTER" : "REGISTER",
                          style: const TextStyle(color: Colors.black)),
                    ),
                  ),
            
),
SizedBox(height: 16),

            // 📌 Event Details
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.event['date'],
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(widget.event['time']),
                      SizedBox(height: 8),
                      Text(
                        "TIME",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(widget.event['time']),
                      SizedBox(height: 8),
                      Text("No. of Registrations"),
                      Text("${hypeCount.toString()} HYPES"),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "FREE/PAID",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text("Free"),
                      SizedBox(height: 8),
                      Text(
                        "HYPE",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text("🔥🔥🔥"),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),

            // 📌 Club Information
            Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    image: DecorationImage(
                      image: NetworkImage(widget.event['logo']), // Ensure this key exists in your event data
                      fit: BoxFit.cover, // Adjusts the image to cover the entire container
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "ORGANIZING CLUB",
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                    Text(
                      widget.event['owner'],
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 16),

            // 📌 Brief Description
            Text(
              "BRIEF DESCRIPTION",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(widget.event['desc']),
            SizedBox(height: 16),

            // 📌 Details & Eligibility Button
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                ),
                onPressed: () {},
                child: Text(
                  "DETAILS & ELIGIBILITY",
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}



  
 