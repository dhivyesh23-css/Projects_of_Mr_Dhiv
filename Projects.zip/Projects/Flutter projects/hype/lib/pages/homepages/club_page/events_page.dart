import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:hype/pages/homepages/club_page/eventdetailspage.dart';

class EventPage extends StatefulWidget {
  final Map<String, dynamic> club;

  const EventPage({super.key, required this.club});

  @override
  State<EventPage> createState() => _EventPageState();
}

class _EventPageState extends State<EventPage> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> events = [];
  bool isLoading = true;
  bool isOwner = false; // Add isOwner state

  @override
  void initState() {
    super.initState();
    _checkOwnershipAndFetchEvents(); // Check ownership before fetching events
  }

  Future<void> _checkOwnershipAndFetchEvents() async {
    isOwner = await checkClubOwnership(
        userId: supabase.auth.currentUser!.id, club: widget.club);
    await fetchEvents(); // Fetch events after ownership check
  }

  Future<void> fetchEvents() async {
    try {
      final response = await supabase
          .from('events')
          .select('*')
          .eq('owner', widget.club['name']);

      final newEvents = List<Map<String, dynamic>>.from(response);

      if (mounted) {
        setState(() {
          events = newEvents;
          isLoading = false;
        });
      }
    } catch (e) {
      print("Error fetching events: $e");
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<bool> checkClubOwnership(
      {required String userId, required Map<String, dynamic> club}) async {
    final supabase = Supabase.instance.client;
    try {
      final response = await supabase
          .from('clubs')
          .select('owner')
          .eq('id', club['id'])
          .eq('owner', userId)
          .single();
      return response != null;
    } catch (e) {
      print("Error checking ownership: $e");
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("${widget.club['name']} Events")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.2,
                children: [
                  // Conditionally show "Add New Events" card
                  if (isOwner)
                    _buildEventCard(
                      context,
                      "Add New Events",
                      Icon(Icons.add,
                          size: 30,
                          color: Theme.of(context).colorScheme.primary),
                      isNewBoard: true,
                    ),
                  ...events.map((event) => _buildEventCard(
                        context,
                        event['name'] ?? 'Unnamed Event',
                        event['poster'] != null
                            ? CircleAvatar(
                                backgroundImage: NetworkImage(event['poster']),
                                radius: 35,
                              )
                            : const Icon(Icons.image, size: 24),
                        event: event,
                      )),
                ],
              ),
      ),
    );
  }

  Widget _buildEventCard(
    BuildContext context,
    String title,
    Widget iconWidget, {
    bool isNewBoard = false,
    Map<String, dynamic>? event,
  }) {
    return GestureDetector(
      onTap: () async {
        if (isNewBoard) {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => EventNewScreen(club: widget.club),
            ),
          );

          if (result == true) {
            fetchEvents();
          }
        } else if (event != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Eventdetailspage(event: event),
            ),
          );
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(20),
        ),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            iconWidget,
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                  fontSize: 16,
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}

class EventNewScreen extends StatefulWidget {
  final Map<String, dynamic> club;

  const EventNewScreen({super.key, required this.club});

  @override
  State<EventNewScreen> createState() => _EventNewScreenState();
}

class _EventNewScreenState extends State<EventNewScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController timeController = TextEditingController();
  final TextEditingController venueController = TextEditingController();
  final TextEditingController posterController = TextEditingController();
  final supabase = Supabase.instance.client;

  Future<void> createEvent() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("User not logged in")),
      );
      return;
    }

    final String name = nameController.text.trim();
    final String description = descController.text.trim();
    final String date = dateController.text.trim();
    final String time = timeController.text.trim();
    final String venue = venueController.text.trim();
    final String poster = posterController.text.trim();

    if (name.isEmpty || description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all required fields")),
      );
      return;
    }

    try {
      await supabase.from('events').insert({
        'name': name,
        'desc': description,
        'date': date,
        'time': time,
        'venue': venue,
        'poster': poster,
        'owner':  widget.club['name'],
        'logo': widget.club['icon'],
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Event created successfully!")),
      );
      Navigator.pop(context, true);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error creating event: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Event")),
      body: SingleChildScrollView(
        child: Center(
          child: SizedBox(
            width: 350,
            child: Column(
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: "Name",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: descController,
                  decoration: const InputDecoration(
                    labelText: "Event Description",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: dateController,
                  decoration: const InputDecoration(
                    labelText: "Event Date",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: timeController,
                  decoration: const InputDecoration(
                    labelText: "Event Time",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: venueController,
                  decoration: const InputDecoration(
                    labelText: "Venue",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: posterController,
                  decoration: const InputDecoration(
                    labelText: "Event Poster URL",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: createEvent,
                      child: const Text("Save"),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text("Cancel"),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}