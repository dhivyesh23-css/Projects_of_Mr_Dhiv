import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:hype/pages/homepages/club_page/events_page.dart';


class ClubDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> club;
  
  const ClubDetailsScreen({super.key, required this.club});
  

  @override
  State<ClubDetailsScreen> createState() => _ClubDetailsScreenState();
}

class _ClubDetailsScreenState extends State<ClubDetailsScreen> {
  bool isMember = false;
  bool isOwner = false; 
  late final String userId;
  bool isEditing = false; // Add editing state
  late Map<String, dynamic> editableClubData;
  @override
  void initState() {
    super.initState();
    userId = Supabase.instance.client.auth.currentUser!.id;
    _checkMembershipAndOwnership();
  }

  Future<void> _checkMembershipAndOwnership() async {
    isMember = await checkClubMembership(userId: userId, club: widget.club);
    isOwner = await checkClubOwnership(userId: userId, club: widget.club);
    if (isOwner) {
      // Initialize editableClubData with a copy of widget.club
      editableClubData = Map.from(widget.club);
    }
    setState(() {});
  }
  Future<bool> checkClubOwnership(
      {required String userId, required Map<String, dynamic> club}) async {
    final supabase = Supabase.instance.client;
    try {
      final response = await supabase
          .from('clubs')
          .select('owner')
          .eq('id', club['id'])
          .eq('owner', userId)
          .single();
      return response != null;
    } catch (e) {
      print("Error checking ownership: $e");
      return false;
    }
  }

  @override
  
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Mode' : 'Club Details'),
        backgroundColor: Colors.amber[700],
        actions: [
          if (isOwner) // Show edit/save button only for the owner
            IconButton(
              icon: Icon(isEditing ? Icons.save : Icons.edit),
              onPressed: () {
                setState(() {
                  if (isEditing) {
                    _updateClubData(); // Update Supabase data
                  }
                  isEditing = !isEditing;
                });
              },
            ),
            if (isOwner && !isEditing) // Delete button (only when not editing)
              IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () => _showDeleteConfirmationDialog(context),
              ),
          
          IconButton(icon: Icon(Icons.search), onPressed: () {Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => EventPage(club: widget.club), //need to pass value of club name to next widget
                        ),
                      );}),
          IconButton(icon: Icon(Icons.notifications), onPressed: () {}),
        ],
      ),
      
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 📌 Club Info Section
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.amber[100],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                                backgroundImage: NetworkImage(widget.club['icon']),
                                radius: 35, // Adjust size as needed
                              ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (isEditing)
                            TextFormField(
                              initialValue: editableClubData['name'],
                              onChanged: (value) =>
                                  editableClubData['name'] = value,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          else
                          Text(
                            widget.club['name'] ?? 'Club Name',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          
                          Text(
                            widget.club['is_verified'] == true
                                ? 'Official Club - ${widget.club['no_mem'] ?? 0} Members'
                                : 'Unofficial Club - ${widget.club['no_mem'] ?? 0} Members',
                            style: TextStyle(color: Colors.black54),
                          ),
                        ],
                      ),
                    ),
                    Icon(Icons.share, color: Colors.black54),
                  ],
                ),
              ),
              SizedBox(height: 16),
              
              // 📌 Club Description Section
              Text(
                'Description',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              const SizedBox(height: 10),
              if (isEditing)
                TextFormField(
                  initialValue: editableClubData['description'],
                  onChanged: (value) => editableClubData['description'] = value,
                  maxLines: 3, // Allow multiple lines for description
                )
              else
                PostCard(
                  text: widget.club['description'] ?? 'No description available',
                  tags: '#${widget.club['club_type'] ?? ''}',
                ),

              const SizedBox(height: 16),

              // 📌 Action Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                   if (isOwner)ActionButton(icon: Icons.person_add, label: 'Invite',onTap:(){_showInviteDialog(context);}),
                  
                  ActionButton(
                    icon: Icons.event,
                    label: 'Events',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => EventPage(club: widget.club), //need to pass value of club name to next widget
                        ),
                      );
                    },
                  ),
                  ActionButton(
                  icon: isMember ? Icons.remove : Icons.add,
                  label: isMember ? 'Leave Club' : 'Join Club',
                  onTap: () async { // Make onTap async
                    await toggleClubMembership( // Await the toggle function
                      userId: Supabase.instance.client.auth.currentUser!.id,
                      club: widget.club,
                      onMembershipChanged: (newIsMember) {
                        setState(() { // Update the state inside setState
                          isMember = newIsMember;
                          if (isMember) {
                            widget.club['member_count'] = (widget.club['member_count'] ?? 0) + 1;
                          } else {
                            widget.club['member_count'] = (widget.club['member_count'] ?? 0) - 1;
                          }
                        });
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(isMember ? 'Joined Club' : 'Left Club'),
                          ),
                        );
                      },
                    );
                  },
                ),
                ],
              ),
              SizedBox(height: 16),

              // 📌 Upload Event Poster Section
              Text(
                'Club Poster',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Container(
              height: 150,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.amber[50],
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.amber[300]!),
              ),
              child: PageView.builder(
                itemCount: 2, // One for upload button, one for image
                itemBuilder: (context, index) {
                  if (index == 1) {
                    return GestureDetector(
                      onTap: null, // Function to pick and upload an image
                      child: Container(
                        width: double.infinity, // Occupy full width
                        margin: const EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          color: Colors.amber[100],
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.amber[400]!),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.camera_alt, size: 40, color: Colors.amber[700]),
                            const Text("Tap to upload", style: TextStyle(color: Colors.black54)),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return Container(
                      width: double.infinity, // Occupy full width
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.amber[400]!),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          widget.club['poster'] ?? 'https://via.placeholder.com/150', // Use fetched URL or a placeholder
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(Icons.image, size: 50, color: Colors.grey); // Fallback icon
                          },
                        ),
                      ),
                    );
                  }
                },
              ),
            ),

              SizedBox(height: 16),

              // 📌 Recent Posts Section
              Text(
                'Recent Posts',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              PostCard(
                text: 'Exciting new hackathon event coming up!',
                tags: '#HACKATHON #${widget.club['name']?.toUpperCase()}',
              ),
              PostCard(
                text: 'Join us for a coding meetup this Friday!',
                tags: '#MEETUP',
              ),
            ],
          ),
        ),
      ),
    );
  }
  Future<void> _updateClubData() async {
    try {
      await Supabase.instance.client
          .from('clubs')
          .update(editableClubData)
          .eq('id', widget.club['id']);

      // Update widget.club with the new data
      widget.club.addAll(editableClubData);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Club data updated!')),
      );
    } catch (e) {
      print('Error updating club data: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error updating data: $e')),
      );
    }
  }


  void _showDeleteConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Delete Club'),
          content: const Text('Are you sure you want to delete this club?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                await _deleteClub();
                Navigator.pop(context); // Close the dialog
                Navigator.pop(context); // Go back to the previous screen
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteClub() async {
    try {
      await Supabase.instance.client
          .from('clubs')
          .delete()
          .eq('id', widget.club['id']);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Club deleted!')),
      );
    } catch (e) {
      print('Error deleting club: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting club: $e')),
      );
    }
  }
  void _showInviteDialog(BuildContext context) {
    String invitedEmail = ''; // Store entered email

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Invite Member'),
          content: TextField(
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(hintText: 'Enter email'),
            onChanged: (value) => invitedEmail = value,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), // Close dialog
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                if (invitedEmail.isNotEmpty) {
                  final invitedUserId = await _getUserIdFromEmail(invitedEmail);
                  if (invitedUserId != null) {
                    await _addMemberToClub(invitedUserId);
                    Navigator.pop(context); // Close dialog
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Member invited!')),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('User not found.')),
                    );
                  }
                }
              },
              child: const Text('Invite'),
            ),
          ],
        );
      },
    );
  }

Future<String?> _getUserIdFromEmail(String email) async {
    try {
      final response = await Supabase.instance.client
          .from('user_profiles') // Replace with your user profile table name
          .select('id')
          .eq('email', email)
          .single();

      return response?['id'] as String?; // Extract user ID
    } catch (e) {
      print('Error getting user ID: $e');
      return null;
    }
  }

  Future<void> _addMemberToClub(String userId) async {
    try {
      await Supabase.instance.client.from('club_members').insert({
        'user_id': userId,
        'club_id': widget.club['id'],
      });

      // Update club member count (similar to joinClub function)
      final currentMemberCount = widget.club['no_mem'] as int? ?? 0;
      await Supabase.instance.client.from('clubs').update({
        'no_mem': currentMemberCount + 1,
      }).eq('id', widget.club['id']);

      widget.club['no_mem'] = currentMemberCount + 1; // Update locally
      setState(() {}); // Important: Update the UI
    } catch (e) {
      print('Error adding member to club: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error inviting member: $e')),
      );
    }
  }
}




class PostCard extends StatelessWidget {
  final String text;
  final String tags;
  const PostCard({super.key, required this.text, required this.tags});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.amber[50],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(text, style: TextStyle(fontSize: 16)),
          SizedBox(height: 5),
          Text(
            tags,
            style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}

class ActionButton extends StatelessWidget {
  
  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  const ActionButton({super.key, required this.icon, required this.label, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          CircleAvatar(
            radius: 25,
            backgroundColor: Colors.amber[700],
            child: Icon(icon, color: Colors.white, size: 30),
          ),
          SizedBox(height: 5),
          Text(
            label,
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}



//////////////////////////////////////


Future<void> toggleClubMembership(
    {required String userId,
    required Map<String, dynamic> club,
    required Function(bool isMember) onMembershipChanged}) async {
    final supabase = Supabase.instance.client;
  bool isMember = await checkClubMembership(userId: userId, club: club);

  try {
    if (isMember) {
      await leaveClub(userId: userId, club: club);
    } else {
      await joinClub(userId: userId, club: club);
    }
    onMembershipChanged(!isMember);
  } catch (e) {
    print("Error toggling club membership: $e");
  }
}

Future<bool> checkClubMembership(
    {required String userId, required Map<String, dynamic> club}) async {
  final supabase = Supabase.instance.client;
  try {
    final List<dynamic> response = await supabase
        .from('club_members')
        .select()
        .eq('user_id', userId)
        .eq('club_id', club['id']);
    return response.isNotEmpty;
  } catch (e) {
    print("Error checking membership: $e");
    return false;
  }
}

Future<void> joinClub(
    {required String userId, required Map<String, dynamic> club}) async {
  final supabase = Supabase.instance.client;
  try {
    await supabase.from('club_members').insert({
      'user_id': userId,
      'club_id': club['id'],
    });

    // Improved no_mem update:
    final currentMemberCount = club['no_mem'] as int? ?? 0; // Handle nulls
    await supabase.from('clubs').update({
      'no_mem': currentMemberCount + 1,
    }).eq('id', club['id']);

    club['no_mem'] = currentMemberCount + 1; // Update the club map as well

  } catch (e) {
    print("Error joining club: $e");
  }
}

Future<void> leaveClub(
    {required String userId, required Map<String, dynamic> club}) async {
  final supabase = Supabase.instance.client;
  try {
    await supabase
        .from('club_members')
        .delete()
        .eq('user_id', userId)
        .eq('club_id', club['id']);

    // Improved no_mem update:
    final currentMemberCount = club['no_mem'] as int? ?? 0; // Handle nulls
    final newCount = currentMemberCount > 0 ? currentMemberCount - 1 : 0; // Prevent negative counts

    await supabase.from('clubs').update({
      'no_mem': newCount,
    }).eq('id', club['id']);

    club['no_mem'] = newCount; // Update the club map as well

  } catch (e) {
    print("Error leaving club: $e");
  }
}