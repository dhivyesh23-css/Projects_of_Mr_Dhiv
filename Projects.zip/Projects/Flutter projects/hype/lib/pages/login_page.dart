import'package:flutter/material.dart';
import 'package:hype/auth/auth_service.dart';
import 'package:hype/pages/register_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  
  final authService = AuthService();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  

  void login() async {
    final email = _emailController.text;
    final password = _passwordController.text;
    
    try {
      await authService.signInwithEmailPassword(email, password);
    } 
    
    catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Error: $e"),
          ),
        );
      }
    }
  }

  //UI

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal:12.0,vertical:50),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: "Email",
              ),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: "Password",
              ),
            ),
            ElevatedButton(
              onPressed: login,
              child: const Text("Login"),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Don't have an account?"),
                SizedBox(width:5),
                GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const RegisterPage()));
                  },
                child:Text("Sign Up", style: TextStyle(color:Theme.of(context).colorScheme.primary)),
                )
              ]
            )
          ]
        ),
      )
    );
  }
}