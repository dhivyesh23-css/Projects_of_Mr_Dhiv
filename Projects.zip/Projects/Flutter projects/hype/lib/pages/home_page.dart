import 'package:flutter/material.dart';
import 'package:hype/auth/auth_service.dart';
import 'package:hype/pages/homepages/schedule_page.dart';
import 'package:hype/pages/homepages/club_page.dart';
import 'package:hype/pages/homepages/profile_page.dart';
import 'package:hype/pages/homepages/realhome_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int currentpage = 0;
  List<Widget> pages=  [
    RealhomePage(),
    SchedulePage(),
    ClubPage(),
    ProfilePage(),
  ];

  final authService = AuthService();

  void logout() async{
    await authService.signOut();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentpage],
      bottomNavigationBar: NavigationBar(
        destinations:const[
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_today), label: 'Schedule'),
          NavigationDestination(icon: Icon(Icons.home), label: 'Clubs'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
        onDestinationSelected: (int index){
          setState((){
            currentpage=index;
          });
        },
        selectedIndex: currentpage,
      ),
    );
  }
}