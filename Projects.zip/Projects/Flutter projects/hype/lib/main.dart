import'package:flutter/material.dart';
import 'package:hype/auth/auth_gate.dart';
import'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  await Supabase.initialize(
    anonKey:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVtYnBoYnhza2draGhxanZhYnp3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAzMzk0NzcsImV4cCI6MjA1NTkxNTQ3N30.RB0nM-tkOdJei9stG04k7B7NqeRBX9CTXcs45lzg2vw",
    url:"https://umbphbxskgkhhqjvabzw.supabase.co",
  );


runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Color.fromARGB(255, 255, 217, 3)),
      ),
      home: AuthGate(),
    );
  }
}